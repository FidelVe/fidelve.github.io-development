import React from "react"
import { graphql } from "gatsby"
import Img from "gatsby-image"
import { Helmet } from "react-helmet"
import countries from "./countries.json"
import fccLogo from "./freecodecamp.png"

// Import page style
import "./style.css"

// Variable declaration
const _CHECKBOX_OPTIONS = [
  "Front-end development",
  "Back-end development",
  "React",
  "Full Stack development",
  "Databases",
  "Angular",
]

const StyledLabel = ({ labelId, labelText, inputName }) => (
  <div className="labels">
    <img className="bulletpoint" src={fccLogo} alt="FCC logo" />
    <label id={labelId} htmlFor={inputName}>
      {labelText}
      {": "}
    </label>
  </div>
)
const StyledInput = ({
  labelId,
  labelText,
  inputType = "text",
  inputName,
  inputId,
  inputClass = "text-input",
  inputPlaceholder,
}) => (
  <div className="input-section">
    <StyledLabel
      labelId={labelId}
      labelText={labelText}
      inputName={inputName}
    />
    <div className="inputs">
      <input
        autoFocus
        type={inputType}
        name={inputName}
        id={inputId}
        className={inputClass}
        placeholder={inputPlaceholder}
        required
      />
    </div>
  </div>
)

const PageBody = props => (
  <div id="body">
    <header id="header">
      <div id="img-container">
        <Img
          style={{ height: "100%" }}
          fluid={props.data.surveyBg.childImageSharp.fluid}
        />
      </div>
      <h1 id="title">FreeCodeCamp 2019 Students Survey</h1>
    </header>
    <main id="main-container">
      <Helmet>
        <title>FreeCodeCamp 2019 Students Survey</title>
        <script
          type="text/javascript"
          src="https://cdn.freecodecamp.org/testable-projects-fcc/v1/bundle.js"
        ></script>
      </Helmet>
      <p id="description">
        The following is an annual survey done to all our students,
        participation is not mandatory but we appreciate you taking your time to
        complete our survey.
      </p>
      <section id="main-survey">
        <form id="survey-form" method="GET" action="">
          {[
            [
              "name-label",
              "First Name",
              "text",
              "first-name",
              "name",
              "First Name",
            ],
            [
              "last-name-label",
              "Last Name",
              "text",
              "last-name",
              "last-name",
              "Last Name",
            ],
            [
              "email-label",
              "Email",
              "email",
              "email",
              "email",
              "Enter Valid email",
            ],
          ].map((values, index) => (
            <StyledInput
              labelId={values[0]}
              labelText={values[1]}
              inputType={values[2]}
              inputName={values[3]}
              inputId={values[4]}
              inputPlaceholder={values[5]}
              key={index}
            />
          ))}
          <div className="input-section">
            <StyledLabel
              labelId="number-label"
              labelText="Age"
              inputName="age"
            />
            <div className="inputs">
              <input
                autoFocus
                type="number"
                name="age"
                id="number"
                min="1"
                max="125"
                className="text-input"
                placeholder="Age"
                required
              />
            </div>
          </div>
          <div className="input-section" id="radio-section">
            <StyledLabel
              labelId="number-label"
              labelText="Gender"
              inputName=""
            />
            <div className="inputs" id="radio-set">
              {["Male", "Female"].map((value, index) => (
                <div id="radio-input" key={index}>
                  <label>{value}</label>
                  <input
                    name="gender-radio-btn"
                    value={index}
                    type="radio"
                    className="gender-radio-btn"
                  />
                </div>
              ))}
            </div>
          </div>
          <div className="input-section">
            <StyledLabel
              labelId="nationality-label"
              labelText="Nationality"
              inputName="nationality"
            />
            <div className="inputs">
              <select
                className="nationality-dropdown"
                id="dropdown"
                name="nationality"
                style={{ width: "150px" }}
                data-component="dropdown"
              >
                {countries.map(({ code, name }, index) => (
                  <option value={code} key={index}>
                    {name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="input-section" id="checkbox-section">
            <StyledLabel
              labelId="interest-label"
              labelText="Select from the following options the ones that best describe your interests"
              inputName="interests"
            />
            <div className="inputs" id="checkbox-set">
              {_CHECKBOX_OPTIONS.map((value, index) => (
                <div className="checkbox-input" key={index}>
                  <input
                    name="interests"
                    value={index}
                    type="checkbox"
                    className="interests-option"
                  />
                  <label>{value}</label>
                </div>
              ))}
            </div>
          </div>
          <div className="input-section" id="comment-section">
            <StyledLabel
              labelId="comment-label"
              labelText="Any comments or suggestions"
              inputName="comment"
            />
            <div className="inputs">
              <textarea
                id="comments"
                className="input-field"
                name="comments"
                placeholder="Enter your comment here..."
              ></textarea>
            </div>
          </div>
          <button id="submit" type="submit">
            Submit
          </button>
        </form>
      </section>
      <footer id="footer"></footer>
    </main>
  </div>
)

export default PageBody

export const query = graphql`
  query {
    surveyBg: file(relativePath: { eq: "header-bg.png" }) {
      childImageSharp {
        fluid(maxWidth: 800) {
          ...GatsbyImageSharpFluid
        }
      }
    }
  }
`
