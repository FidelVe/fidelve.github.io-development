import React from "react"
import { Helmet } from "react-helmet"

// Import page style
import "./style.css"

export default () => (
  <main id="main">
    <Helmet>
      <title>Stan Lee Tribute</title>
      <script
        type="text/javascript"
        src="https://cdn.freecodecamp.org/testable-projects-fcc/v1/bundle.js"
      ></script>
    </Helmet>
    <header id="header">
      <h1 id="title">Stan Lee</h1>
      <p className="quote">The man behind the heroes of our era</p>
      <div id="img-div">
        <img
          id="image"
          src="https://upload.wikimedia.org/wikipedia/commons/4/42/Stan_Lee_in_the_army.jpg"
          alt="Stan Lee in the Army"
        />
        <p id="img-caption" className="quote">
          Stan Lee during his time in the Army-{" "}
          <a
            rel="noopener noreferrer"
            href="https://blog.togetherweserved.com/2017/06/30/sgt-stan-lee-us-army-served-1942-1945/"
          >
            https://blog.togetherweserved.com/2017/06/30/sgt-stan-lee-us-army-served-1942-1945/
          </a>
          , Public Domain,{" "}
          <a
            href="https://commons.wikimedia.org/w/index.php?curid=74351724"
            rel="noopener noreferrer"
          >
            Link
          </a>
        </p>
      </div>
    </header>
    <section id="tribute-info">
      <p>
        Stan Lee, was an American comic book writer, editor, publisher, and
        producer. He rose through the ranks of a family-run business to become
        Marvel Comics' primary creative leader for two decades, leading its
        expansion from a small division of a publishing house to a multimedia
        corporation that dominated the comics industry.
      </p>

      <p>
        In collaboration with others at Marvel—particularly co-writer/artists
        Jack Kirby and Steve Ditko—he co-created numerous popular fictional
        characters, including superheroes Spider-Man, the X-Men, Iron Man, Thor,
        the Hulk, the Fantastic Four, Black Panther, Daredevil, Doctor Strange,
        Scarlet Witch and Ant-Man. In doing so, he pioneered a more naturalistic
        approach to writing superhero comics in the 1960s, and in the 1970s he
        challenged the restrictions of the Comics Code Authority, indirectly
        leading to changes in its policies. In the 1980s he pursued development
        of Marvel properties in other media, with mixed results. Following his
        retirement from Marvel in the 1990s, he remained a public figurehead for
        the company, and frequently made cameo appearances in films and
        television shows based on Marvel characters, on which he received an
        executive producer credit. Meanwhile, he continued independent creative
        ventures into his 90s, until his death in 2018.
      </p>

      <p>
        Lee was inducted into the comic book industry's Will Eisner Award Hall
        of Fame in 1994 and the Jack Kirby Hall of Fame in 1995. He received the
        NEA's National Medal of Arts in 2008.
      </p>
    </section>
    <footer id="footer">
      <img
        id="img-footer"
        src="https://i.imgur.com/KTpAv8q.jpg"
        alt="Stan Lee with Kevin Smith"
      />
      <p className="quote">
        This is how I’ll always see you, @therealstanlee: as our benevolent
        leader and king, smiling down from your eternal throne on the
        generations of imaginations you fed and inspired.
      </p>
      <p className="quote">--Movie Director, Kevin Smith</p>
      <p>
        <a
          id="tribute-link"
          href="https://en.wikipedia.org/wiki/Stan_Lee"
          target="_blank"
          rel="noopener noreferrer"
        >
          Wikipedia Page about Stan Lee
        </a>
      </p>
    </footer>
  </main>
)
