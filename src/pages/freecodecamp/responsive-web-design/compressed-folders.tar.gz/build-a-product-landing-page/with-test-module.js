import React from "react"
import { graphql } from "gatsby"
import Img from "gatsby-image"
import { Helmet } from "react-helmet"

// Import page style
import "./style.css"

// Variable declaration
const PageBody = props => (
  <div id="product-main">
    <Helmet>
      <title>GUITAR ZONE STORE</title>
      <script
        type="text/javascript"
        src="https://cdn.freecodecamp.org/testable-projects-fcc/v1/bundle.js"
      ></script>
    </Helmet>
    <header id="header">
      <div id="logo-container">
        <img
          id="header-img"
          src="https://i.imgur.com/ULJ1Ih7.png"
          alt="guitar logo"
        />
        <h2 id="logo-heading">Guitar Zone</h2>
      </div>
      <nav id="nav-bar">
        <a className="nav-link" href="#section1">
          <b>Our Product</b>
        </a>
        <a className="nav-link" href="#section2">
          <b>How it Works</b>
        </a>
        <a className="nav-link" href="#section3">
          <b>Contact Us</b>
        </a>
      </nav>
    </header>
    <main id="main">
      <section className="section" id="section1">
        <h2>OUR PRODUCTS</h2>
        <p>
          Our concert guitars are sought after for their elegant sound, musical
          flexibility, clarity, projection, balance, easy playability, old
          master grade materials, and immaculate workmanship: concert
          instruments which mature with responsible care and loving use. To this
          end the classical guitars we commission result from ongoing
          discussions with internationally renowned concert artists, the world’s
          most gifted luthiers, and prominent teachers.
        </p>
        <p>
          We ship our guitars nationally on seventy-two hours approval and
          display them by appointment in our shop in Cleveland, Ohio. Our goal
          is to match each client – student, teacher, concert artist,
          aficionado, or collector – with the guitar which will inspire the
          greatest artistry and joy.
        </p>
      </section>
      <section className="section" id="section2">
        <h2>HOW IT WORKS</h2>
        <iframe
          title="Guitar Zone"
          width="560"
          height="315"
          id="video"
          src="https://www.youtube.com/embed/RFPnZayG0VI"
          frameBorder="0"
          allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        ></iframe>
      </section>
      <section className="section" id="section3">
        <h2>CONTACT US</h2>
        <form id="form" action="https://www.freecodecamp.com/email-submit">
          <div className="input-section">
            <label id="name-label" htmlFor="name">
              Name:{" "}
            </label>
            <input
              autoFocus
              type="text"
              name="name"
              id="name-input"
              placeholder="Enter Your Name"
              required
            />
          </div>
          <div className="input-section">
            <label id="email-label" htmlFor="email">
              Email:{" "}
            </label>
            <input
              autoFocus
              type="email"
              name="email"
              id="email"
              placeholder="Enter valid email"
              required
            />
          </div>
          <div className="input-section" id="comment-section">
            <textarea
              id="comment-input"
              name="comments"
              placeholder="Any question about our products? write it here."
            ></textarea>
          </div>
          <input id="submit" type="submit"></input>
        </form>
      </section>
      <footer id="footer">
        <h3>Copyright 2016, Guitar Zone</h3>
      </footer>
    </main>
  </div>
)

export default PageBody

export const query = graphql`
  query {
    surveyBg: file(relativePath: { eq: "header-bg.png" }) {
      childImageSharp {
        fluid(maxWidth: 800) {
          ...GatsbyImageSharpFluid
        }
      }
    }
  }
`

// {
//   /*   <head> */
// }
// {
//   /*     <meta charset="utf-8"> */
// }
// {
//   /*     <meta name="viewport" content="width=device-width, initial-scale=1.0"> */
// }
// {
//   /*     <link type="text/css" rel="stylesheet" href="./style.css"> */
// }
// {
//   /*   </head> */
// }
// {
//   /*   <body> */
// }
// {
// }
// {
//   /*   </body> */
// }
// {
//   /* </html> */
// }
